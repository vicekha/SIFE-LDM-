#!/usr/bin/env python3
"""
SIFE-LDM Inference Script (v3.0 - dual text+vision)
==================================================

Generate text (NLP mode) or images (vision mode) using a trained SIFE-LDM.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Optional, List, Tuple

import jax
import jax.numpy as jnp
import numpy as np

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from sife.model import SIFELDM, SIFELDMConfig, load_checkpoint
from sife.field import SIFEConfig
from sife.diffusion import DiffusionConfig, GaussianDiffusion, DDIMSampler
from sife.tokenizer import Vocabulary, SIFETokenizer

def parse_args():
    parser = argparse.ArgumentParser(description='SIFE-LDM inference (text or vision)')
    parser.add_argument('--mode', type=str, default='text', choices=['text', 'vision'])
    parser.add_argument('--checkpoint', type=str, required=True)
    parser.add_argument('--config', type=str, default=None)
    parser.add_argument('--vocab', type=str, default=None)
    parser.add_argument('--prompt', type=str, default=None)
    parser.add_argument('--max_length', type=int, default=256)
    parser.add_argument('--output_image', type=str, default=None)
    parser.add_argument('--label', type=int, default=None)
    parser.add_argument('--image_size', type=str, default=None)
    parser.add_argument('--num_steps', type=int, default=50)
    return parser.parse_args()

def load_model(checkpoint_path: str, config_path: Optional[str] = None):
    if config_path is None:
        config_path = os.path.join(os.path.dirname(checkpoint_path), '..', 'config.json')

    if not os.path.exists(config_path):
        print(f"Warning: Config file not found at {config_path}. Using defaults.")
        config_dict = {}
    else:
        with open(config_path, 'r') as f:
            config_dict = json.load(f)

    model_cfg = config_dict.get('model', config_dict) # Merge nested objects
    flat_cfg = dict(model_cfg)
    if 'sife' in config_dict:
        s = config_dict['sife']
        flat_cfg['sife'] = SIFEConfig(**s) if isinstance(s, dict) else SIFEConfig(*s)
    if 'diffusion' in config_dict:
        d = config_dict['diffusion']
        flat_cfg['diffusion'] = DiffusionConfig(**d) if isinstance(d, dict) else DiffusionConfig(*d)
    
    # Handle image_size tuple conversion
    if 'image_size' in flat_cfg and isinstance(flat_cfg['image_size'], list):
        flat_cfg['image_size'] = tuple(flat_cfg['image_size'])

    # Build config: filter keys to only those in SIFELDMConfig._fields
    valid_keys = set(SIFELDMConfig._fields)
    filtered_cfg = {k: v for k, v in flat_cfg.items() if k in valid_keys}
    
    # Use defaults for missing fields to avoid TypeError in NamedTuple init
    config = SIFELDMConfig(**filtered_cfg)

    from sife.model import create_train_state
    temp_key = jax.random.PRNGKey(0)
    model, init_state, diffusion = create_train_state(config, temp_key)
    print(f"Restoring parameters from {checkpoint_path}...")
    state = load_checkpoint(checkpoint_path, init_state)
    return model, state, diffusion, config

def generate_vision_sample(model, params, diffusion, config, args):
    if args.image_size:
        w, h = map(int, args.image_size.split('x'))
        shape = (1, h // config.patch_size, w // config.patch_size, (config.patch_size**2) * config.image_channels)
    else:
        h, w = config.image_size
        shape = (1, h // config.patch_size, w // config.patch_size, (config.patch_size**2) * config.image_channels)

    key = jax.random.PRNGKey(0)
    context = None
    if args.label is not None:
        context = jnp.array([args.label], dtype=jnp.int32)
        print(f"[vision] Generating class-conditional image (label {args.label})...")
    else:
        print(f"[vision] Generating unconditional image ({args.image_size or config.image_size})...")

    ddim = DDIMSampler(diffusion)
    
    def model_fn(x, t, ctx):
        return model.apply(params, x, t, labels=ctx, deterministic=True)
    
    latent = ddim.sample(model_fn, shape, key, context, num_steps=args.num_steps)
    
    try:
        rgb = model.apply(params, latent, method=model.decode_images)
    except Exception as e:
        print(f"[vision] Warning: learned decoding failed ({e}). Falling back to amplitude.")
        amp = jnp.abs(latent)
        mn, mx = amp.min(), amp.max()
        rgb = (amp-mn)/(mx-mn+1e-8)
        
    return np.array(rgb[0])

def _save_image(img_np: np.ndarray, path: str) -> None:
    img_uint8 = (np.clip(img_np, 0.0, 1.0) * 255).astype(np.uint8)
    try:
        from PIL import Image as PILImage
        mode = 'L' if img_uint8.shape[-1] == 1 else 'RGB'
        data = img_uint8[..., 0] if mode == 'L' else img_uint8
        PILImage.fromarray(data, mode=mode).save(path)
        print(f"[vision] Image saved to {path}")
    except Exception as e:
        print(f"[vision] PIL failed: {e}. Saving as NPY.")
        np.save(path.replace('.png', '.npy'), img_np)

def main():
    args = parse_args()
    model, state, diffusion, config = load_model(args.checkpoint, args.config)

    if args.mode == 'vision':
        img = generate_vision_sample(model, state.params, diffusion, config, args)
        _save_image(img, args.output_image or 'sife_generated.png')
        return

    # Text mode logic (simplified)
    vocab_path = args.vocab or os.path.join(os.path.dirname(args.checkpoint), '..', 'vocab.json')
    vocab = Vocabulary.load(vocab_path)
    tokenizer = SIFETokenizer(vocab=vocab, embed_dim=config.embed_dim, max_seq_len=config.max_seq_len)
    
    print(f"[text] Prompt: {args.prompt}")
    # ... call generate (simplified for verification)
    print("[text] Generation completed (dummy output for now).")

if __name__ == '__main__':
    main()
