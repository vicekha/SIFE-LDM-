#!/usr/bin/env python3
"""
SIFE-LDM Training Script (v3.0 - dual text+vision)
==================================================

Interleaved training for text (NLP) and vision (Image) modalities.

Usage:
    python train.py --mode vision --image_data data/images/
    python train.py --mode text --data data/text.txt
    python train.py --mode both --data data/text.txt --image_data data/images/
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple

import jax
import jax.numpy as jnp
import numpy as np

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from sife.model import (
    SIFELDMConfig, SIFELDM, create_train_state, 
    save_checkpoint, load_checkpoint, train_step
)
from sife.field import SIFEConfig
from sife.diffusion import DiffusionConfig
from sife.multiscale import create_multiscale_config
from sife.tokenizer import Vocabulary, SIFETokenizer

def parse_args():
    parser = argparse.ArgumentParser(description='Train SIFE-LDM (Text + Vision)')
    
    # -- Modality -------------------------------------------------------------
    parser.add_argument('--mode', type=str, default='both', 
                        choices=['text', 'vision', 'both'],
                        help='Training mode: text | vision | both')

    # -- Data -----------------------------------------------------------------
    parser.add_argument('--data', type=str, default=None,
                        help='Path to text training data')
    parser.add_argument('--image_data', type=str, default=None,
                        help='Path to directory of images (vision mode)')
    parser.add_argument('--vocab', type=str, default=None,
                        help='Path to pre-built vocabulary')
    
    # -- Model ----------------------------------------------------------------
    parser.add_argument('--embed_dim', type=int, default=256)
    parser.add_argument('--num_heads', type=int, default=8)
    parser.add_argument('--num_blocks', type=int, default=4)
    parser.add_argument('--max_seq_len', type=int, default=1024)
    parser.add_argument('--image_size', type=str, default="32x32")
    
    # -- Training -------------------------------------------------------------
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--learning_rate', type=float, default=0.03) # ANDI default
    parser.add_argument('--weight_decay', type=float, default=0.01)
    parser.add_argument('--warmup_steps', type=int, default=1000)
    parser.add_argument('--num_classes', type=int, default=0,
                        help='Number of classes for conditional generation (0 = unconditional)')
    parser.add_argument('--max_steps', type=int, default=100000)
    
    # -- SIFE -----------------------------------------------------------------
    parser.add_argument('--sife_mass', type=float, default=1.0)
    parser.add_argument('--sife_coupling', type=float, default=1.0)
    parser.add_argument('--phase_coupling_lambda', type=float, default=0.05)
    
    # -- Output ---------------------------------------------------------------
    parser.add_argument('--output_dir', type=str, default='output')
    parser.add_argument('--checkpoint_dir', type=str, default='checkpoints')
    parser.add_argument('--save_every', type=int, default=1000)
    parser.add_argument('--resume', type=str, default=None)

    return parser.parse_args()

def create_config_from_args(args) -> SIFELDMConfig:
    # Parse image size
    w, h = map(int, args.image_size.split('x'))
    
    return SIFELDMConfig(
        model_type=args.mode,
        embed_dim=args.embed_dim,
        num_heads=args.num_heads,
        num_blocks=args.num_blocks,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        warmup_steps=args.warmup_steps,
        max_steps=args.max_steps,
        max_seq_len=args.max_seq_len,
        phase_coupling_lambda=args.phase_coupling_lambda,
        image_size=(w, h),
        is_image=(args.mode in ('vision', 'both')),
        num_classes=args.num_classes,
        sife=SIFEConfig(m=args.sife_mass, k=args.sife_coupling)
    )

class VisionLoader:
    """Image loader supporting both directory-of-files and pre-processed numpy arrays."""
    def __init__(self, path: str, image_size: Tuple[int, int], batch_size: int, num_classes: int = 0):
        self.path = path
        self.image_size = image_size
        self.batch_size = batch_size
        self.num_classes = num_classes
        self.labels_npy = None
        
        # Auto-detect pre-processed numpy data (e.g., CIFAR-100)
        npy_path = os.path.join(path, 'train_images.npy') if path else ''
        if path and os.path.exists(npy_path):
            self.mode = 'numpy'
            self.images_npy = np.load(npy_path)
            labels_path = os.path.join(path, 'train_labels.npy')
            if os.path.exists(labels_path):
                self.labels_npy = np.load(labels_path).flatten()
                # Auto-detect num_classes from labels
                if self.num_classes == 0:
                    self.num_classes = int(self.labels_npy.max()) + 1
            print(f"[vision] Loaded {len(self.images_npy)} images from numpy arrays"
                  f" ({self.num_classes} classes)" if self.labels_npy is not None else "")
        else:
            # Directory-of-files fallback
            self.mode = 'directory'
            self.images = []
            if path and os.path.exists(path):
                import glob
                exts = ['*.png', '*.jpg', '*.jpeg']
                for e in exts:
                    self.images.extend(glob.glob(os.path.join(path, '**', e), recursive=True))
            print(f"[vision] Found {len(self.images)} images in {path}")
            if len(self.images) == 0:
                print("[vision] WARNING: No images found. Using random placeholder images.")

    def __iter__(self):
        while True:
            if self.mode == 'numpy':
                idx = np.random.randint(0, len(self.images_npy), self.batch_size)
                batch_images = self.images_npy[idx].astype(np.float32)
                if batch_images.max() > 1.0:
                    batch_images = batch_images / 255.0
                result = {'images': jnp.array(batch_images)}
                if self.labels_npy is not None:
                    result['labels'] = jnp.array(self.labels_npy[idx].astype(np.int32))
                    # 15% CFG dropout
                    result['use_context_mask'] = jnp.array(
                        np.random.uniform(size=self.batch_size) > 0.15
                    )
                yield result
            else:
                from PIL import Image
                batch = []
                for _ in range(self.batch_size):
                    if len(self.images) > 0:
                        idx = np.random.randint(0, len(self.images))
                        try:
                            img = Image.open(self.images[idx]).convert('RGB')
                            img = img.resize(self.image_size)
                            batch.append(np.array(img).astype(np.float32) / 255.0)
                        except:
                            batch.append(np.zeros((*self.image_size, 3), dtype=np.float32))
                    else:
                        batch.append(np.random.rand(*self.image_size, 3).astype(np.float32))
                yield {'images': jnp.array(batch)}

def main():
    args = parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    os.makedirs(args.checkpoint_dir, exist_ok=True)
    
    config = create_config_from_args(args)
    
    # Save config
    config_path = os.path.join(args.output_dir, 'config.json')
    with open(config_path, 'w') as f:
        # Simple serialization of NamedTuple/SIFELDMConfig
        def serialize(obj):
            if hasattr(obj, '_asdict'): return obj._asdict()
            if isinstance(obj, (tuple, list)): return [serialize(x) for x in obj]
            return obj
        json.dump(serialize(config), f, indent=2)

    # Prepare Data Loaders
    text_iter = None
    if args.mode in ('text', 'both'):
        from sife.tokenizer import create_training_data
        print(f"[text] Initializing tokenizer and vocab...")
        # Check if we need to build vocab
        if args.vocab and os.path.exists(args.vocab):
            vocab = Vocabulary.load(args.vocab)
        else:
            vocab = Vocabulary(min_freq=2, max_size=32000)
            if args.data and os.path.exists(args.data):
                with open(args.data, 'r', encoding='utf-8') as f:
                    texts = [line.strip() for line in f if line.strip()]
                vocab.build_from_texts(texts[:10000])
            else:
                # Minimal dummy vocab if no data provided
                vocab.build_from_texts(["hello world", "sife ldm", "dual vision text"])
            vocab.save(os.path.join(args.output_dir, 'vocab.json'))
        
        tokenizer = SIFETokenizer(vocab=vocab, embed_dim=args.embed_dim, max_seq_len=args.max_seq_len)
        text_dataset, _ = create_training_data(tokenizer, text_path=args.data, batch_size=args.batch_size)
        text_iter = iter(text_dataset)
        print(f"[text] Vocabulary ({len(vocab)} tokens) loaded and saved to {args.output_dir}/vocab.json")

    vision_iter = None
    if args.mode in ('vision', 'both'):
        vl = VisionLoader(args.image_data, config.image_size, args.batch_size, config.num_classes)
        # If VisionLoader auto-detected num_classes and the config has 0, rebuild config
        if vl.num_classes > 0 and config.num_classes == 0:
            config = config._replace(num_classes=vl.num_classes)
            print(f"[config] Auto-set num_classes={config.num_classes} from data labels")
        vision_iter = iter(vl)

    # Initialize Model
    print("[model] Initialising ...")
    key = jax.random.PRNGKey(42)
    model, state, diffusion = create_train_state(config, key)
    
    if args.resume:
        print(f"[model] Resuming from {args.resume}")
        state = load_checkpoint(args.resume, state)
    
    from sife.model import create_optimizer
    optimizer = create_optimizer(config)
    
    # Training Loop
    print(f"[training] Starting {args.mode} training for {args.max_steps} steps...")
    start_time = time.time()
    
    for step in range(1, args.max_steps + 1):
        # Interleave batches if mode is 'both'
        if args.mode == 'both':
            # Alternate batches: text then vision
            batch = next(text_iter) if step % 2 == 1 else next(vision_iter)
        elif args.mode == 'text':
            batch = next(text_iter)
        else:
            batch = next(vision_iter)
            
        state, metrics = train_step(model, state, batch, diffusion, optimizer)
        
        if step % 100 == 0 or step == 1:
            elapsed = time.time() - start_time
            print(f"[{args.mode}] Step {step}/{args.max_steps} | Loss: {metrics['loss']:.4f} | Time: {elapsed:.2f}s")
            
        if step % args.save_every == 0:
            save_checkpoint(state, args.checkpoint_dir, step)
            
    # Final save
    save_checkpoint(state, args.checkpoint_dir, args.max_steps, name='final')
    print(f"[training] Completed. Checkpoints saved to {args.checkpoint_dir}")

if __name__ == '__main__':
    main()
